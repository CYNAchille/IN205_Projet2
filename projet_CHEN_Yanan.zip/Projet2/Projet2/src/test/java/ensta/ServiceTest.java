package ensta;


import com.ensta.librarymanager.service.*;

public class ServiceTest {

	public static void main(String args[])throws Exception{ 
		System.out.println(MembreServiceImpl.getInstance().getListMembreEmpruntPossible());
		System.out.println(MembreServiceImpl.getInstance().getList());
		System.out.println(LivreServiceImpl.getInstance().getListDispo());
		System.out.println(LivreServiceImpl.getInstance().getList());
	} 
}
