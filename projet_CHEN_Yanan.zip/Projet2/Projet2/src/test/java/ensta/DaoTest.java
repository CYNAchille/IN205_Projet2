package ensta;
import com.ensta.librarymanager.dao.*;

import java.time.LocalDate;

import com.ensta.librarymanager.modele.*;


public class DaoTest {

	public static void main(String args[])throws Exception{ 
		Membre membre = null; 

		membre = new Membre(); 
		MembreDaoImpl.getInstance().create("Chen", "Yanan", "ensta", "yanan.chen@ensta-paris.fr", "0666763125"); 
		
		System.out.println(MembreDaoImpl.getInstance().getList());
		System.out.println(LivreDaoImpl.getInstance().getList());
		System.out.println(EmpruntDaoImpl.getInstance().getList());
		System.out.println(EmpruntDaoImpl.getInstance().getListCurrent());
		System.out.println(EmpruntDaoImpl.getInstance().getListCurrentByLivre(3));
		System.out.println(111);
		Emprunt emprunt=EmpruntDaoImpl.getInstance().getById(1);
		emprunt.setDateRetour(null);
		System.out.println(emprunt);
		//EmpruntDaoImpl.getInstance().update(emprunt);
		EmpruntDaoImpl.getInstance().create(1, 2, LocalDate.now());
		System.out.println(EmpruntDaoImpl.getInstance().getList());
	} 

}
