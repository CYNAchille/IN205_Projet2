package ensta;
import com.ensta.librarymanager.modele.*;

public class ModeleTest {

	public static void main(String args[]) {
		Membre m= new Membre(16,"chen","Yanan","ENSTA","@","3366","VIP");
		Livre l=new Livre();
		
		Emprunt e= new Emprunt(100,m,l);
		
		System.out.println(e.toString());
		System.out.println(m.getAbonnement().getValue());
	}
}
