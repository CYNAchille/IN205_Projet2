package com.ensta.librarymanager.exception;

public class ServiceException extends Exception{
	public ServiceException() {
		super();
	}
	public ServiceException(String msg) {
		super(msg);
	}
	
	public static void isVide(String s) throws ServiceException {
		if(s=="") {
			throw new ServiceException("Vide string!");
		}
	}
}
