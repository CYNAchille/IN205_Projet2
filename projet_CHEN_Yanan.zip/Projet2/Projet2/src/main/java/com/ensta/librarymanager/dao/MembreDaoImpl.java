package com.ensta.librarymanager.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.ensta.librarymanager.exception.DaoException;
import com.ensta.librarymanager.modele.Membre;
import com.ensta.librarymanager.persistence.ConnectionManager;

public class MembreDaoImpl implements MembreDao{
	private Connection conn = null ;
	private PreparedStatement pstmt = null ;
	private static MembreDaoImpl instance;

	public MembreDaoImpl(){}

	public static MembreDaoImpl getInstance(){
		if (instance == null){
			instance = new MembreDaoImpl();
		}
		return instance;
	}
	
	public MembreDaoImpl(Connection conn)
	{
		this.conn = conn;
	}
	
	public List<Membre> getList() throws DaoException {
		List<Membre> all = new ArrayList<Membre>();
		String sql = "SELECT id, nom, prenom, adresse, email, telephone, abonnement "
				+ "FROM membre "
				+ "ORDER BY nom, prenom"; 
		try {
			conn=ConnectionManager.getConnection();
			this.pstmt = this.conn.prepareStatement(sql);
			ResultSet rs = this.pstmt.executeQuery();
			Membre membre = null;
			while(rs.next())
			{
				membre = new Membre();
				membre.setId(rs.getInt(1));
				membre.setNom(rs.getString(2)) ;
				membre.setPrenom(rs.getString(3)) ;
				membre.setAdresse(rs.getString(4)) ;
				membre.setEmail(rs.getString(5)) ;
				membre.setTelephone(rs.getString(6)) ;
				membre.setAbonnement(rs.getString(7)) ;
				all.add(membre);
			}
			this.pstmt.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return all;
	}

	@Override
	public Membre getById(int id) throws DaoException {
		String sql = "SELECT id, nom, prenom, adresse, email, telephone, abonnement "
				+ "FROM membre "
				+ "WHERE id = ?"; 
		Membre membre = null;
		try {
			conn=ConnectionManager.getConnection();
			this.pstmt = this.conn.prepareStatement(sql);
			this.pstmt.setInt(1,id) ;
			ResultSet rs = this.pstmt.executeQuery();
			if(rs.next())
			{
				membre.setId(rs.getInt(1));
				membre.setNom(rs.getString(2)) ;
				membre.setPrenom(rs.getString(3)) ;
				membre.setAdresse(rs.getString(4)) ;
				membre.setEmail(rs.getString(5)) ;
				membre.setTelephone(rs.getString(6)) ;
				membre.setAbonnement(rs.getString(7)) ;
			}
			this.pstmt.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return membre;
	}

	@Override
	public int create(String nom, String prenom, String adresse, String email, String telephone) throws DaoException {
		String sql = "INSERT INTO membre(nom, prenom, adresse, email, telephone, "
				+ "abonnement) "
				+ "VALUES (?, ?, ?, ?, ?, ?)";
		int id = 0;
		try {
			conn=ConnectionManager.getConnection();
			this.pstmt=this.conn.prepareStatement(sql,Statement.RETURN_GENERATED_KEYS);
			this.pstmt.setString(1,nom);
			this.pstmt.setString(2,prenom);
			this.pstmt.setString(3,adresse);
			this.pstmt.setString(4,email);
			this.pstmt.setString(5,telephone);
			this.pstmt.setString(6,"BASIC");
			this.pstmt.executeUpdate();
			ResultSet rs = this.pstmt.getGeneratedKeys();
			if(rs.next()) {
				id = rs.getInt(1);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return 0;
		}
		return id;
	}

	@Override
	public void update(Membre membre) throws DaoException {
		String sql = "UPDATE membre "
				+ "SET nom = ?, prenom = ?, adresse = ?, email = ?, telephone = ?, "
				+ "abonnement = ? "
				+ "WHERE id = ?"; 
		try {
			conn=ConnectionManager.getConnection();
			this.pstmt = this.conn.prepareStatement(sql);
			this.pstmt.setString(1,membre.getNom()) ;
			this.pstmt.setString(2,membre.getPrenom()) ;
			this.pstmt.setString(3,membre.getAdresse()) ;
			this.pstmt.setString(4,membre.getEmail()) ;
			this.pstmt.setString(5,membre.getTelephone()) ;
			this.pstmt.setString(6,membre.getAbonnement().name()) ;
			this.pstmt.setInt(6,membre.getId()) ;
			this.pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				this.pstmt.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}


	}

	@Override
	public void delete(int id) throws DaoException {
		String sql = "DELETE FROM membre WHERE id = ?"; 
		try {
			conn=ConnectionManager.getConnection();
			this.pstmt = this.conn.prepareStatement(sql);
			this.pstmt.setInt(1,id) ;
			this.pstmt.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				this.pstmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

	}

	@Override
	public int count() throws DaoException {
		String sql = "SELECT COUNT(id) AS count FROM membre;"; 
		int cnt=0;
		try {
			conn=ConnectionManager.getConnection();
			this.pstmt = this.conn.prepareStatement(sql);
			ResultSet rs = this.pstmt.executeQuery();
			if(rs.next())
			{
				cnt=rs.getInt("count");
			}
			this.pstmt.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return cnt;
	}
	

}
