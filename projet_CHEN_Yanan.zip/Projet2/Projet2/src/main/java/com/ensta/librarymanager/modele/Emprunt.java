package com.ensta.librarymanager.modele;
import java.time.LocalDate;


public class Emprunt {
	private int id;
	private Membre membre;
	private Livre livre;
	private LocalDate dateEmprunt;
	private LocalDate dateRetour;
	
	public Emprunt() {
		this.membre=new Membre();
		this.livre=new Livre();
	}
	
	public Emprunt(int id, Membre membre,Livre livre) {
		this.id=id;
		this.membre=membre;
		this.livre=livre;
		dateEmprunt=LocalDate.now();
	}
	
	public int getId() {
		return this.id;
	}
	public Membre getMembre() {
		return this.membre;
	}
	
	public Livre getLivre() {
		return this.livre;
	}
	
	public LocalDate getDateEmprunt() {
		return this.dateEmprunt;
	}
	
	public LocalDate getDateRetour() {
		return this.dateRetour;
	}
	
	public void setId(int id) {
		this.id=id;
	}
	
	public void setMembre(int idMembre, String nom, String prenom,String  adresse, 
			String email, String telephone,String abonnement) {
		this.membre.setId(idMembre);
		this.membre.setNom(nom);
		this.membre.setPrenom(prenom);
		this.membre.setAdresse(adresse);
		this.membre.setEmail(email);
		this.membre.setTelephone(telephone);
		this.membre.setAbonnement(abonnement);
	}
	
	
	
	public void setLivre(int idLivre, String titre, String auteur, String isbn) {
		this.livre.setId(idLivre);
		this.livre.setTitre(titre);
		this.livre.setAuteur(auteur);
		this.livre.setIsbn(isbn);
	}
	
	public void setDateEmprunt(LocalDate dateEmprunt) {
		this.dateEmprunt=dateEmprunt;
	}
	
	public void setDateRetour(LocalDate dateRetour) {
		this.dateRetour=dateRetour;
	}
	
	public String toString() {
		return "("+String.valueOf(id)+", "+String.valueOf(membre.getId())+", "+dateEmprunt+", "+dateRetour+")";
		
	}

}
