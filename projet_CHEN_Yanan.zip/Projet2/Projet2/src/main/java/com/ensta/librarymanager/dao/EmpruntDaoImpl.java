package com.ensta.librarymanager.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.ensta.librarymanager.exception.DaoException;
import com.ensta.librarymanager.modele.Emprunt;
import com.ensta.librarymanager.persistence.ConnectionManager;

public class EmpruntDaoImpl implements EmpruntDao{
	private Connection conn = null ;
	private PreparedStatement pstmt = null ;
	private static EmpruntDaoImpl instance;

	public EmpruntDaoImpl()
	{
	}


	public static EmpruntDaoImpl getInstance(){
		if (instance == null){
			instance = new EmpruntDaoImpl();
		}
		return instance;
	}

	public EmpruntDaoImpl(Connection conn)
	{
		this.conn = conn;
	}

	@Override
	public List<Emprunt> getList() throws DaoException {
		List<Emprunt> all = new ArrayList<Emprunt>();
		String sql = "SELECT e.id AS id, idMembre, nom, prenom, adresse, email, telephone, "
				+ "abonnement, idLivre, titre, auteur, isbn, dateEmprunt, dateRetour "
				+ "FROM emprunt AS e "
				+ "INNER JOIN membre ON membre.id = e.idMembre"
				+ " INNER JOIN livre ON livre.id = e.idLivre"
				+ " ORDER BY dateRetour DESC "; 
		try {
			conn=ConnectionManager.getConnection();
			this.pstmt = this.conn.prepareStatement(sql);
			ResultSet rs = this.pstmt.executeQuery();
			Emprunt emprunt = null;
			while(rs.next())
			{
				emprunt = new Emprunt();
				emprunt.setId(rs.getInt(1));
				emprunt.setMembre(rs.getInt(2), rs.getString(3), rs.getString(4), rs.getString(5),
						rs.getString(6), rs.getString(7), rs.getString(8));
				emprunt.setLivre(rs.getInt(9), rs.getString(10), rs.getString(11), rs.getString(12)) ;
				emprunt.setDateEmprunt(rs.getDate(13).toLocalDate());
				if (rs.getDate(14)==null)
					emprunt.setDateRetour(null);
				else
					emprunt.setDateRetour(rs.getDate(14).toLocalDate());
				all.add(emprunt);
			}
			this.pstmt.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return all;
	}

	@Override
	public List<Emprunt> getListCurrent() throws DaoException {
		List<Emprunt> all = new ArrayList<Emprunt>();
		String sql = "SELECT e.id AS id, idMembre, nom, prenom, adresse, email, telephone, abonnement, "
				+ "idLivre, titre, auteur, isbn, dateEmprunt, dateRetour "
				+ "FROM emprunt AS e "
				+ "INNER JOIN membre ON membre.id = e.idMembre "
				+ "INNER JOIN livre ON livre.id = e.idLivre "
				+ "WHERE dateRetour IS NULL;"; 
		try {
			conn=ConnectionManager.getConnection();
			this.pstmt = this.conn.prepareStatement(sql);
			ResultSet rs = this.pstmt.executeQuery();
			Emprunt emprunt = null;
			while(rs.next())
			{
				emprunt = new Emprunt();
				emprunt.setId(rs.getInt(1));
				emprunt.setMembre(rs.getInt(2), rs.getString(3), rs.getString(4), rs.getString(5),
						rs.getString(6), rs.getString(7), rs.getString(8));
				emprunt.setLivre(rs.getInt(9), rs.getString(10), rs.getString(11), rs.getString(12)) ;
				emprunt.setDateEmprunt(rs.getDate(13).toLocalDate());
				if (rs.getDate(14)==null)
					emprunt.setDateRetour(null);
				else
					emprunt.setDateRetour(rs.getDate(14).toLocalDate());
				all.add(emprunt);
			}
			this.pstmt.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return all;
	}

	@Override
	public List<Emprunt> getListCurrentByMembre(int idMembre) throws DaoException {
		List<Emprunt> all = new ArrayList<Emprunt>();
		String sql = "SELECT e.id AS id, idMembre, nom, prenom, adresse, email, telephone, abonnement, "
				+ "idLivre, titre, auteur, isbn, dateEmprunt, dateRetour "
				+ "FROM emprunt AS e "
				+ "INNER JOIN membre ON membre.id = e.idMembre "
				+ "INNER JOIN livre ON livre.id = e.idLivre "
				+ "WHERE dateRetour IS NULL AND membre.id = ?;"; 
		try {
			conn=ConnectionManager.getConnection();
			this.pstmt = this.conn.prepareStatement(sql);
			this.pstmt.setInt(1,idMembre) ;
			ResultSet rs = this.pstmt.executeQuery();
			Emprunt emprunt = null;
			while(rs.next())
			{
				emprunt = new Emprunt();
				emprunt.setId(rs.getInt(1));
				emprunt.setMembre(rs.getInt(2), rs.getString(3), rs.getString(4), rs.getString(5),
						rs.getString(6), rs.getString(7), rs.getString(8));
				emprunt.setLivre(rs.getInt(9), rs.getString(10), rs.getString(11), rs.getString(12)) ;
				emprunt.setDateEmprunt(rs.getDate(13).toLocalDate());
				if (rs.getDate(14)==null)
					emprunt.setDateRetour(null);
				else
					emprunt.setDateRetour(rs.getDate(14).toLocalDate());
				all.add(emprunt);
			}
			this.pstmt.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return all;
	}

	@Override
	public List<Emprunt> getListCurrentByLivre(int idLivre) throws DaoException {
		List<Emprunt> all = new ArrayList<Emprunt>();
		String sql = "SELECT e.id AS id, idMembre, nom, prenom, adresse, email, telephone, abonnement, "
				+ "idLivre, titre, auteur, isbn, dateEmprunt, dateRetour "
				+ "FROM emprunt AS e "
				+ "INNER JOIN membre ON membre.id = e.idMembre "
				+ "INNER JOIN livre ON livre.id = e.idLivre "
				+ "WHERE dateRetour IS NULL AND livre.id = ?;"; 
		try {
			conn=ConnectionManager.getConnection();
			this.pstmt = this.conn.prepareStatement(sql);
			this.pstmt.setInt(1,idLivre) ;
			ResultSet rs = this.pstmt.executeQuery();
			Emprunt emprunt = null;
			while(rs.next())
			{
				emprunt = new Emprunt();
				emprunt.setId(rs.getInt(1));
				emprunt.setMembre(rs.getInt(2), rs.getString(3), rs.getString(4), rs.getString(5),
						rs.getString(6), rs.getString(7), rs.getString(8));
				emprunt.setLivre(rs.getInt(9), rs.getString(10), rs.getString(11), rs.getString(12)) ;
				emprunt.setDateEmprunt(rs.getDate(13).toLocalDate());
				if (rs.getDate(14)==null)
					emprunt.setDateRetour(null);
				else
					emprunt.setDateRetour(rs.getDate(14).toLocalDate());
				all.add(emprunt);
			}
			this.pstmt.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return all;
	}

	@Override
	public Emprunt getById(int id) throws DaoException {
		Emprunt emprunt=null;
		String sql = "SELECT e.id AS id, idMembre, nom, prenom, adresse, email, telephone, abonnement, "
				+ "idLivre, titre, auteur, isbn, dateEmprunt, dateRetour "
				+ "FROM emprunt AS e "
				+ "INNER JOIN membre ON membre.id = e.idMembre "
				+ "INNER JOIN livre ON livre.id = e.idLivre "
				+ "WHERE e.id = ?"; 
		try {
			conn=ConnectionManager.getConnection();
			this.pstmt = this.conn.prepareStatement(sql);
			this.pstmt.setInt(1,id) ;
			ResultSet rs = this.pstmt.executeQuery();
			if(rs.next())
			{
				emprunt = new Emprunt();
				emprunt.setId(rs.getInt(1));
				emprunt.setMembre(rs.getInt(2), rs.getString(3), rs.getString(4), rs.getString(5),
						rs.getString(6), rs.getString(7), rs.getString(8));
				emprunt.setLivre(rs.getInt(9), rs.getString(10), rs.getString(11), rs.getString(12)) ;
				emprunt.setDateEmprunt(rs.getDate(13).toLocalDate());
				if (rs.getDate(14)==null)
					emprunt.setDateRetour(null);
				else
					emprunt.setDateRetour(rs.getDate(14).toLocalDate());
			}
			this.pstmt.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return emprunt;
	}

	@Override
	public void create(int idMembre, int idLivre, LocalDate dateEmprunt) throws DaoException {
		String sql = "INSERT INTO emprunt(idMembre, idLivre, dateEmprunt, dateRetour) VALUES (?, ?, ?, ?)";
		int id = 0;
		try {
			conn=ConnectionManager.getConnection();
			this.pstmt=this.conn.prepareStatement(sql,Statement.RETURN_GENERATED_KEYS);
			this.pstmt.setInt(1,idMembre);
			this.pstmt.setInt(2,idLivre);
			this.pstmt.setString(3,dateEmprunt.toString());
			this.pstmt.setDate(4,null);
			this.pstmt.executeUpdate();
			ResultSet rs = this.pstmt.getGeneratedKeys();
			if(rs.next()) {
				id = rs.getInt(1);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public void update(Emprunt emprunt) throws DaoException {
		String sql = "UPDATE emprunt SET idMembre = ?, idLivre = ?, dateEmprunt = ?, dateRetour = ? WHERE id = ?;"; 
		try {
			conn=ConnectionManager.getConnection();
			this.pstmt = this.conn.prepareStatement(sql);
			this.pstmt.setInt(1,emprunt.getMembre().getId()) ;
			this.pstmt.setInt(2,emprunt.getLivre().getId()) ;
			this.pstmt.setString(3,emprunt.getDateEmprunt().toString()) ;
			if (emprunt.getDateRetour()==null)
				this.pstmt.setDate(4,null) ;
			else
				this.pstmt.setString(4,emprunt.getDateRetour().toString()) ;
			this.pstmt.setInt(5,emprunt.getId()) ;
			this.pstmt.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				this.pstmt.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}

	@Override
	public int count() throws DaoException {
		String sql = "SELECT COUNT(id) AS count FROM emprunt"; 
		int cnt=0;
		try {
			conn=ConnectionManager.getConnection();
			this.pstmt = this.conn.prepareStatement(sql);
			ResultSet rs = this.pstmt.executeQuery();
			if(rs.next())
			{
				cnt=rs.getInt("count");
			}
			this.pstmt.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return cnt;
	}
}


