package com.ensta.librarymanager.dao;

public enum Abonnement {
	BASIC("BASIC",5), PREMIUM("PREMIUM",5), VIP("VIP",20);
	private String name;
	private int value;
    private Abonnement( String name,int value) {  
        this.name = name;  
        this.value=value;
    } 
    public int getValue() {
    	return this.value;
    }
}
