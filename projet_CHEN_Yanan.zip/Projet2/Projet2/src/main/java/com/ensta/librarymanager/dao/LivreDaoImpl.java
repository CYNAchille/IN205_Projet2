package com.ensta.librarymanager.dao;

import java.util.ArrayList;
import java.util.List;

import com.ensta.librarymanager.exception.DaoException;
import com.ensta.librarymanager.modele.Livre;
import com.ensta.librarymanager.persistence.ConnectionManager;

import java.sql.*;



public class LivreDaoImpl implements LivreDao{
	private Connection conn = null ;
	private PreparedStatement pstmt = null ;
	private static LivreDaoImpl instance;

	public LivreDaoImpl()
	{
	}


	public static LivreDaoImpl getInstance(){
		if (instance == null){
			instance = new LivreDaoImpl();
		}
		return instance;
	}
	public LivreDaoImpl(Connection conn)
	{
		this.conn = conn;
	}

	public List<Livre> getList() throws DaoException {
		List<Livre> all = new ArrayList<Livre>();
		String sql = "SELECT id, titre, auteur, isbn FROM livre"; 
		try {
			conn=ConnectionManager.getConnection();
			this.pstmt = this.conn.prepareStatement(sql);
			ResultSet rs = this.pstmt.executeQuery();
			Livre livre = null;
			while(rs.next())
			{
				livre = new Livre();
				livre.setId(rs.getInt(1));
				livre.setTitre(rs.getString(2)) ;
				livre.setIsbn(rs.getString(3)) ;
				all.add(livre);
			}
			this.pstmt.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return all;
	}
	@Override
	public Livre getById(int id) throws DaoException {
		String sql = "SELECT id, titre, auteur, isbn FROM livre WHERE id = ?"; 
		Livre livre = null;
		try {
			conn=ConnectionManager.getConnection();
			this.pstmt = this.conn.prepareStatement(sql);
			this.pstmt.setInt(1,id) ;
			ResultSet rs = this.pstmt.executeQuery();
			if(rs.next())
			{
				livre.setId(rs.getInt(1));
				livre.setTitre(rs.getString(2)) ;
				livre.setIsbn(rs.getString(3)) ;
			}
			this.pstmt.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return livre;
	}

	@Override
	public int create(String titre, String auteur, String isbn) throws DaoException {
		String sql = "INSERT INTO livre(titre, auteur, isbn) VALUES (?, ?, ?)";
		int id = 0;
		try {
			conn=ConnectionManager.getConnection();
			this.pstmt=this.conn.prepareStatement(sql,Statement.RETURN_GENERATED_KEYS);
			this.pstmt.setString(1,titre);
			this.pstmt.setString(2,auteur);
			this.pstmt.setString(3,isbn);
			this.pstmt.executeUpdate();
			ResultSet rs = this.pstmt.getGeneratedKeys();
			if(rs.next()) {
				id = rs.getInt(1);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return 0;
		}
		return id;
	}

	@Override
	public void update(Livre livre) throws DaoException {
		String sql = "UPDATE livre SET titre = ?, auteur = ?, isbn = ? WHERE id = ?"; 
		try {
			conn=ConnectionManager.getConnection();
			this.pstmt = this.conn.prepareStatement(sql);
			this.pstmt.setString(1,livre.getTitre()) ;
			this.pstmt.setString(2,livre.getAuteur()) ;
			this.pstmt.setString(3,livre.getIsbn()) ;
			this.pstmt.setInt(4,livre.getId()) ;
			this.pstmt.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				this.pstmt.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}


	}

	@Override
	public void delete(int id) throws DaoException {
		String sql = "DELETE FROM livre WHERE id = ?"; 
		try {
			conn=ConnectionManager.getConnection();
			this.pstmt = this.conn.prepareStatement(sql);
			this.pstmt.setInt(1,id) ;
			this.pstmt.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				this.pstmt.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	@Override
	public int count() throws DaoException {
		String sql = "SELECT COUNT(id) AS count FROM livre;"; 
		int cnt=0;
		try {
			conn=ConnectionManager.getConnection();
			this.pstmt = this.conn.prepareStatement(sql);
			ResultSet rs = this.pstmt.executeQuery();
			if(rs.next())
			{
				cnt=rs.getInt("count");
			}
			this.pstmt.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return cnt;
	}

}
