package com.ensta.librarymanager.service;

import java.util.ArrayList;
import java.util.List;

import com.ensta.librarymanager.dao.MembreDaoImpl;
import com.ensta.librarymanager.exception.DaoException;
import com.ensta.librarymanager.exception.ServiceException;
import com.ensta.librarymanager.modele.Emprunt;
import com.ensta.librarymanager.modele.Membre;

public class MembreServiceImpl implements MembreService{
	private static MembreServiceImpl instance;
	private MembreDaoImpl membreDao;

	public MembreServiceImpl(){}

	public static MembreServiceImpl getInstance(){
		if (instance == null){
			instance = new MembreServiceImpl();
		}
		return instance;
	}
	

	public List<Membre> getList() throws ServiceException {
		List<Membre> all = new ArrayList<Membre>();
		try {
			all=MembreDaoImpl.getInstance().getList();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return all;
	}

	@Override
	public List<Membre> getListMembreEmpruntPossible() throws ServiceException {
		List<Membre> all = new ArrayList<Membre>();
		List<Membre> MEP = new ArrayList<Membre>();
		try {
			all=MembreDaoImpl.getInstance().getList();
		} catch (DaoException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		for (int i = 0; i < all.size(); i++) {
			Membre membre=all.get(i);
			if (EmpruntServiceImpl.getInstance().isEmpruntPossible(membre)) {
				MEP.add(membre);
			}
		}
		return MEP;
	}

	@Override
	public Membre getById(int id) throws ServiceException {
		Membre membre = new Membre();
		try {
			membre=MembreDaoImpl.getInstance().getById(id);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return membre;
	}

	@Override
	public int create(String nom, String prenom, String adresse, String email, String telephone)
			throws ServiceException {
		int id=0;
		try {
			ServiceException.isVide(nom);
			ServiceException.isVide(prenom);
			id=MembreDaoImpl.getInstance().create(nom.toUpperCase(), prenom, adresse, email, telephone);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return id;
	}

	@Override
	public void update(Membre membre) throws ServiceException {
		try {
			ServiceException.isVide(membre.getNom());
			ServiceException.isVide(membre.getPrenom());
			membre.setNom(membre.getNom().toUpperCase());
			MembreDaoImpl.getInstance().update(membre);
		} catch (DaoException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	@Override
	public void delete(int id) throws ServiceException {
		try {
			MembreDaoImpl.getInstance().delete(id);
		} catch (DaoException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	@Override
	public int count() throws ServiceException {
		int cnt=0;
		try {
			MembreDaoImpl.getInstance().count();
		} catch (DaoException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return cnt;
	}

}
