package com.ensta.librarymanager.modele;

public class Livre {
	private int id;
	private String titre;
	private String auteur;
	private String isbn;
	
	public Livre() {
	}
	
	public void setId(int id) {
		this.id=id;
	}
	
	public void setTitre(String titre) {
		this.titre=titre;
	}
	
	public void setAuteur(String auteur) {
		this.auteur=auteur;
	}
	
	public void setIsbn(String isbn) {
		this.isbn=isbn;
	}
	
	public int getId() {
		return this.id;
	}
	
	public String getTitre() {
		return this.titre;
	}
	
	public String getAuteur() {
		return this.auteur;
	}
	
	public String getIsbn() {
		return this.isbn;
	}
	
	public String toString() {
		return "("+String.valueOf(id)+", "+titre+", "+auteur+", "+isbn+")";
	}
}
