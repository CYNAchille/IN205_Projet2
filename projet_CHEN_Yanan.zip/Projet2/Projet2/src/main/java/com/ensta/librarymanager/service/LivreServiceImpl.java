package com.ensta.librarymanager.service;

import java.util.ArrayList;
import java.util.List;

import com.ensta.librarymanager.dao.LivreDaoImpl;
import com.ensta.librarymanager.dao.MembreDaoImpl;
import com.ensta.librarymanager.exception.DaoException;
import com.ensta.librarymanager.exception.ServiceException;
import com.ensta.librarymanager.modele.Emprunt;
import com.ensta.librarymanager.modele.Livre;
import com.ensta.librarymanager.modele.Membre;

public class LivreServiceImpl implements LivreService{
	private static LivreServiceImpl instance;
	

	public LivreServiceImpl(){}

	public static LivreServiceImpl getInstance(){
		if (instance == null){
			instance = new LivreServiceImpl();
		}
		return instance;
	}
	@Override
	public List<Livre> getList() throws ServiceException {
		List<Livre> all = new ArrayList<Livre>();
		try {
			all=LivreDaoImpl.getInstance().getList();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return all;
	}

	@Override
	public List<Livre> getListDispo() throws ServiceException {
		List<Livre> all = new ArrayList<Livre>();
		List<Livre> dispoList = new ArrayList<Livre>();
		try {
			all=LivreDaoImpl.getInstance().getList();
		} catch (DaoException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		for (int i = 0; i < all.size(); i++) {
			Livre livre=all.get(i);
			if (EmpruntServiceImpl.getInstance().isLivreDispo(livre.getId())) {
				dispoList.add(livre);
			}
		}
		return dispoList;
	}

	@Override
	public Livre getById(int id) throws ServiceException {
		Livre livre= new Livre();
		try {
			livre=LivreDaoImpl.getInstance().getById(id);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return livre;
	}

	@Override
	public int create(String titre, String auteur, String isbn) throws ServiceException {
		int id=0;
		try {
			ServiceException.isVide(titre);
			id=LivreDaoImpl.getInstance().create(titre, auteur, isbn);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return id;
	}

	@Override
	public void update(Livre livre) throws ServiceException {
		try {
			ServiceException.isVide(livre.getTitre());
			LivreDaoImpl.getInstance().update(livre);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	@Override
	public void delete(int id) throws ServiceException {
		try {
			LivreDaoImpl.getInstance().delete(id);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	@Override
	public int count() throws ServiceException {
		int cnt=0;
		try {
			cnt=LivreDaoImpl.getInstance().count();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return cnt;
	}

}
