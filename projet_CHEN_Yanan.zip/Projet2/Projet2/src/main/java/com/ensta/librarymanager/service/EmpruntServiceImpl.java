package com.ensta.librarymanager.service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.ensta.librarymanager.dao.EmpruntDaoImpl;
import com.ensta.librarymanager.dao.MembreDaoImpl;
import com.ensta.librarymanager.exception.DaoException;
import com.ensta.librarymanager.exception.ServiceException;
import com.ensta.librarymanager.modele.Emprunt;
import com.ensta.librarymanager.modele.Membre;

public class EmpruntServiceImpl implements EmpruntService{
	private static EmpruntServiceImpl instance;
	

	public EmpruntServiceImpl(){}

	public static EmpruntServiceImpl getInstance(){
		if (instance == null){
			instance = new EmpruntServiceImpl();
		}
		return instance;
	}
	
	@Override
	public List<Emprunt> getList() throws ServiceException {
		List<Emprunt> all = new ArrayList<Emprunt>();
		try {
			all=EmpruntDaoImpl.getInstance().getList();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return all;
	}

	@Override
	public List<Emprunt> getListCurrent() throws ServiceException {
		List<Emprunt> all = new ArrayList<Emprunt>();
		try {
			all=EmpruntDaoImpl.getInstance().getListCurrent();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return all;
	}

	@Override
	public List<Emprunt> getListCurrentByMembre(int idMembre) throws ServiceException {
		List<Emprunt> all = new ArrayList<Emprunt>();
		try {
			all=EmpruntDaoImpl.getInstance().getListCurrentByMembre(idMembre);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return all;
	}

	@Override
	public List<Emprunt> getListCurrentByLivre(int idLivre) throws ServiceException {
		List<Emprunt> all = new ArrayList<Emprunt>();
		try {
			all=EmpruntDaoImpl.getInstance().getListCurrentByLivre(idLivre);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return all;
	}

	@Override
	public Emprunt getById(int id) throws ServiceException {
		Emprunt emprunt=new Emprunt();
		try {
			emprunt=EmpruntDaoImpl.getInstance().getById(id);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return emprunt;
	}

	@Override
	public void create(int idMembre, int idLivre, LocalDate dateEmprunt) throws ServiceException {
		try {
			EmpruntDaoImpl.getInstance().create(idMembre, idLivre, dateEmprunt);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	@Override
	public void returnBook(int id) throws ServiceException {
		Emprunt emprunt=new Emprunt();
		try {
			emprunt = EmpruntDaoImpl.getInstance().getById(id);
			emprunt.setDateRetour(LocalDate.now());
			EmpruntDaoImpl.getInstance().update(emprunt);
		} catch (DaoException e) {
			e.printStackTrace();
		}
	}

	@Override
	public int count() throws ServiceException {
		int cnt=0;
		try {
			cnt = EmpruntDaoImpl.getInstance().count();
		} catch (DaoException e) {
			e.printStackTrace();
		}
		return cnt;
	}

	@Override
	public boolean isLivreDispo(int idLivre) throws ServiceException {
		List<Emprunt> all = new ArrayList<Emprunt>();
		boolean dispo = true;
		try {
			all =EmpruntDaoImpl.getInstance().getListCurrentByLivre(idLivre);
		} catch (DaoException e) {
			e.printStackTrace();
		}
		for (int i = 0; i < all.size(); i++) {
			Emprunt emprunt=all.get(i);
			if (emprunt.getDateRetour()==null) {
				dispo=false;
				break;
			}
		}
		return dispo;
	}

	@Override
	public boolean isEmpruntPossible(Membre membre) throws ServiceException {
		List<Emprunt> all = new ArrayList<Emprunt>();
		int cnt=0;
		int capacite=membre.getAbonnement().getValue();
		try {
			all =EmpruntDaoImpl.getInstance().getListCurrentByMembre(membre.getId());
		} catch (DaoException e) {
			e.printStackTrace();
		}
		for (int i = 0; i < all.size(); i++) {
			Emprunt emprunt=all.get(i);
			if (emprunt.getDateRetour()==null) {
				cnt++;
			}
		}
		if (cnt<capacite)
			return true;
		else
			return false;
	}

}
